<?php session_start();

if(isset($_POST))
{
	include_once'db_connection.php';
	
	$name    =	$_POST['name'];
	$email   =	$_POST['email'];
	$password=	$_POST['password'];
	$credit_card  =	$_POST['credit_card'];
	$gender	 =	$_POST['gender'];
	$dob	 =	$_POST['dob'];

	//subject field is check box type, we stored into db by comma seperate.

	
	$address 	 =	$_POST['address'];

	$to_upload_path = "";
	
	if(isset($_FILES) && !empty($_FILES))
	{
		$filename = $_FILES["profile_pic"]["name"];
		$to_upload_path = "uploads/".$filename;
		move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $to_upload_path);		
	}
	

	// write sql query for inserting data into users table.	
	  $sql = "INSERT INTO  users  set 
	    name    =  '$name',
	   	password = '$password',
	    email   =  '$email',
	    credit_card  =  '$credit_card',
	    gender  =  '$gender',
	    dob  =  '$dob',
	    address   =   '$address',
	    profile_pic = '$to_upload_path' ";

	if ($conn->query($sql)) {		
		$_SESSION['message'] = "User Successfully Created";
		header("Location:index.php");
	} else {
		$_SESSION['message'] = "Error, Please try again";
		header("Location:register_user.php");
	}
		
	$conn->close();
} 
?>