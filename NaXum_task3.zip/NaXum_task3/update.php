<?php
//check of user id logged in otherwise sent on login page.
include 'session_check.php';

// to get database connection.
include 'db_connection.php';

if(isset($_POST))
{
	//print_r($_POST);die('tesitng');

	$userId  =	$_POST['id'];
	$name    =	$_POST['name'];
	$dob    =	$_POST['dob'];
	$email   =	$_POST['email'];
	$credit_card  =	$_POST['credit_card'];
	$gender	 =	$_POST['gender'];
	$redirect_page = $_POST['redirect_page'];

	//subject field is check box type, we stored into db by comma seperate.

	
	
	$address 	 =	$_POST['address'];
	
	$to_upload_path = "";
	if(isset($_FILES) && !empty($_FILES['profile_pic']['name']))
	{
		$filename = $_FILES["profile_pic"]["name"];
		$to_upload_path = "uploads/".$filename;
		move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $to_upload_path);
	}
	else{
		$to_upload_path = $_POST['old_image'];
	}
	
	// write sql query for inserting data into users table.	
	$sql  = "UPDATE users SET 
	name    =  '$name',
	email   =  '$email',
	dob = '$dob',
	credit_card  =  '$credit_card',
	gender  =  '$gender',
	address   =   '$address',
	profile_pic = '$to_upload_path'
	where id = '$userId' ";

	if ($conn->query($sql) === TRUE) {
		 
		  $_SESSION['message'] = "Successfully Updated";       
			if($redirect_page == 'no'){
			header("Location:view_all_user.php");
			}else{
			header("Location:update-user-profile.php");
			}
	
	} else {

   $_SESSION['message'] = "Error, Please try again";
   if($redirect_page == 'no'){
       	header("Location:view_all_user.php");
       }else{
		header("Location:update-user-profile.php");
		}
	}

$conn->close();
} 
?>