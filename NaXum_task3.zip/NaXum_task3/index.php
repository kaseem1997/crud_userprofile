<?php session_start();?>
<!DOCTYPE html>
<html>
<head><title>User Login</title>
	
</head>
<body>

<p align="center">

<?php if(isset($_SESSION['message'])){echo $_SESSION['message'];
unset($_SESSION['message']);}?>


</p>

<form action="login_controller.php" method="post" enctype="multipart/form-data">

<table border="1" width="40%" align="center" >

	<tr>
	 <td width="30%">Email/User Id</td>
	 <td width="10%" align="center"> : </td>
	 <td width="30%"><input class="text-style" required="required" type="text" name="email" id="email"> </td>	
    </tr>
  
    <tr>
	 <td> Password </td>
	 <td width="10%" align="center"> : </td>
	 <td><input class="text-style" required="required" type="password" name="password" id="password"></td>	
    </tr>
    
    <tr>
	 <td colspan="3" align="center"> <input type="submit" value="Login" name="submit"> </td>
	</tr>	
</form>
</table>
<p align="center">Don't have account, please  register <a href="register-user.php"> here </a> </p>
</body>
</html>