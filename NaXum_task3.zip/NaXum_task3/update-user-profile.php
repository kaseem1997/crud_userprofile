<?php
//check of user id logged in otherwise sent on login page.
include 'session_check.php';

// to get database connection.
include 'db_connection.php';

$userId = $_SESSION['userData']['id'];
$isOwnProfile = 'yes';
if(isset($_GET['id']) && !empty($_GET['id']) )
{
	$userId = $_GET['id'];	
	$isOwnProfile = 'no';
}

$sel_query = "SELECT * FROM users WHERE id = '$userId'";
$data = $conn->query($sel_query)->fetch_assoc();
?>

Welcome to  <b> <?php echo $_SESSION['userData']['name'];?>

<?php /* you can write this too*/ //echo $data['name'];?> </b>

<div class="div_width" id="textbox">
  <div class="alignleft">
  	<?php include 'left_panel.php';?>
  </div>
  <div class="alignright">
  	<?php if(isset($_SESSION['message'])){echo "<p align='center' > ".$_SESSION['message']."</p>";unset($_SESSION['message']);}?>
  	<p align="center">User Profile Details </p>
  	 <form action="update.php" method="post" enctype="multipart/form-data">

<table border="1" width="40%" align="center" >

	<tr>
	 <td width="30%"> Name </td>
	 <td width="10%" align="center"> : </td>
	 <td width="30%"><input class="text-style" value="<?php echo $data['name'];?>" required="required" type="text" name="name" id="name"> </td>	
    </tr>

    <tr>
	 <td> DOB </td>
	 <td width="10%" align="center"> : </td>
	 <td width="30%"><input class="text-style" value="<?php echo $data['dob'];?>" required="required" type="form-data" name="dob" id="dob"> </td>
    </tr>

    <tr>
	 	<td> Gender </td>
		 <td width="10%" align="center"> : </td>
	 		<td>
	 			<input required="required" type="radio" <?php if($data['gender']=='Male'){echo "checked";}?> name="gender" id="gender" value="Male"> Male
	 			<input required="required" <?php if($data['gender']=='Female'){echo "checked";}?> type="radio" name="gender" id="gender" value="Female"> Female
	 		</td>	
   </tr>

   <tr>
	 <td> Complete Address </td>
	 <td width="10%" align="center"> : </td>
	 <td width="30%"><input class="text-style" value="<?php echo $data['address'];?>" required="required" type="text" name="address" id="address" placeholder="Write full address"> </td>
    </tr>

    <tr>
	 <td> Profile Picture </td>
	 <td width="10%" align="center"> : </td>
	 <td><input  type="file" name="profile_pic" id="profile_pic">
      <?php if(!empty($data['profile_pic'])) { ?>       	
      	<img src="<?php echo $data['profile_pic'];?>" height="50">      	
      <?php }?>
      <input type="hidden" name="old_image" value="<?php echo $data['profile_pic'];?>">      
      <input type="hidden" name="id" value="<?php echo $data['id'];?>">      
      <input type="hidden" name="redirect_page" value="<?php echo $isOwnProfile;?>">      
      </td>	
    </tr>

    <tr>
	 <td> Credit Card </td>
	 <td width="10%" align="center"> : </td>
	 <td><input class="text-style" value="<?php echo $data['credit_card'];?>" required="required" type="number" name="credit_card" id="credit_card"> </td>	
    </tr>
  
    <tr>
	 <td> Email/User Id </td>
	 <td width="10%" align="center"> : </td>
	 <td><input class="text-style" required="required" value="<?php echo $data['email'];?>" type="text" name="email" id="email"></td>	
    </tr>

   <tr>
	 <td colspan="3" align="center"> <input type="submit" value="Update" name="submit"> </td>
	</tr>

	  
</form>

</table>

  </div>
</div>