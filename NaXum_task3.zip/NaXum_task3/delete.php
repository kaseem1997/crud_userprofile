<?php
//check of user id logged in otherwise sent on login page.
include 'session_check.php';

// to get database connection.
include 'db_connection.php';

if(isset($_GET['id']))
{
	$userId = $_GET['id'];
	// write sql query for inserting data into users table.	
	$sql = "delete from users where id = '$userId'";

	if ($conn->query($sql) === TRUE) {
	$_SESSION['message'] = "User Deleted Successfully";	
	header("Location:view_all_user.php");
	} else {
	$_SESSION['message'] = "Error, User Not Deleted";		
	header("Location:view_all_user.php");
	}
	$conn->close();

} 
?>