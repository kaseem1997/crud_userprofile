<?php
if(isset($_POST))
{	
	session_start();
	include_once'db_connection.php';
	
	$email   =	$_POST['email'];
	$password=	$_POST['password'];
	
	// write sql query for inserting data into users table.	
	  $sql = "SELECT * FROM users  WHERE email   =  '$email' AND password =  '$password' ";	  
	  // Record found 
	  
	  $foundRecord = $conn->query($sql)->num_rows;

	 if ($foundRecord) {
	 	// run again query and store data into session to display who is logged in.
		$result = $conn->query($sql);
		$_SESSION["userData"] = $result->fetch_assoc();
		
		// redirect to user dashboard page.
		header("Location:update-user-profile.php");

	} else {		
		// redirect to login page.
		$_SESSION["message"] = "Invalid user id and password, please try again"; 
		header("Location:index.php");
	}
		
	$conn->close();
} 
?>