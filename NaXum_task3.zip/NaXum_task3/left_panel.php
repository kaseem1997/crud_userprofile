
<style type="text/css">
	.alignleft {
	float: left;width:20%;
}
.alignright {
	float: right;width:80%;
}
.div_width{width:70%;float: center;}
</style>


<ul>
		<li><a href="update-user-profile.php"><b> View Profile</a></li><br>
		<li><a href="change-password.php">Change Password</a></li><br>
  		<li><a href="view_all_user.php">View All User</a></li><br>
  		<li><a href="logout.php">Logout</a></li><br>
</ul>