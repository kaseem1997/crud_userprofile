-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 21, 2022 at 04:22 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `naxum_task3`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `credit_card` varchar(50) NOT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `register_date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `dob`, `email`, `password`, `credit_card`, `gender`, `address`, `profile_pic`, `register_date_time`) VALUES
(7, 'Kaseem Ansari', '1212-12-12', 'ansari@gmail.com', '123456', '9807890654321456', 'Male', 'Delhi, INDIA', 'uploads/photo.jpg', '2020-07-25 18:29:54'),
(8, 'Sakira', '2002-12-22', 'sakira@gmail.com', '123456789', '4567898765432109', 'Female', 'Mumbai, INDIA', 'uploads/t1.jfif', '2020-07-25 21:08:18'),
(9, 'Arohi Khanna', '1999-11-29', 'arohi@gmail.com', '123456', '8765901234564321', 'Female', 'Banglore, INDIA', 'uploads/t2.jfif', '2020-07-25 21:11:02'),
(10, 'test', '1111-11-11', 'rajvi@gmail.com', '123456', '9090989887765123', 'Male', 'Surat, INDIA', 'uploads/t3.jfif', '2020-07-25 21:13:55'),
(19, 'Kaseem Ahmad', '2000-01-01', 'kaseem@gmail.com', '1212', '1267890327503788', 'Male', 'Bijnor, UP, INDIA', 'uploads/pic.jpg', '2022-12-21 21:25:02');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
