<?php
//check of user id logged in otherwise sent on login page.
include 'session_check.php';

// to get database connection.
include 'db_connection.php';
$userId = $_SESSION['userData']['id'];

if(isset($_POST))
{	
	$password   =	$_POST['password'];
	$cnpassword =	$_POST['cnpassword'];

	  $sql = "SELECT password FROM users  WHERE id   =  '$userId' ";
	  $data = $conn->query($sql)->fetch_assoc();
	  
	  if($data['password'] != $_POST['oldpassword'])
	  {
	  	$_SESSION['message'] = "old password, doesn't match, Please try again";
  		 header("Location:change-password.php");
	  }
	else if($password != $cnpassword)
	{
		 $_SESSION['message'] = "password, and confirm password doesn't match, Please try again";
  		 header("Location:change-password.php");
    }
  else{	
		// write sql query for inserting data into users table.	
		$sql  = "UPDATE users SET 
		password = '$password'
		where id = '$userId' ";

		if ($conn->query($sql) === TRUE) {
			 
			  $_SESSION['message'] = "Successfully Updated";       
				header("Location:change-password.php");
		
		} else {
	   		$_SESSION['message'] = "Error, Please try again";
	   		header("Location:change-password.php");
		}

	}	

$conn->close();
} 
?>