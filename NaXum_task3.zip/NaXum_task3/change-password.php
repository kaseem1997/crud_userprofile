<?php
//check of user id logged in otherwise sent on login page.
include 'session_check.php';

// to get database connection.
include 'db_connection.php';

$userId = $_SESSION['userData']['id'];
$sel_query = "SELECT * FROM users WHERE id = '$userId'";
$data = $conn->query($sel_query)->fetch_assoc();
?>

Welcome to <b> <?php echo $_SESSION['userData']['name'];?> </b>

<div class="div_width" id="textbox">
  <div class="alignleft">
  	<?php include 'left_panel.php';?>
  </div>
 
  <div class="alignright">
  	<?php if(isset($_SESSION['message'])){echo "<p align='center' > ".$_SESSION['message']."</p>";unset($_SESSION['message']);}?>

  	<p align="center">Change password page </p>

<form action="change_password_controller.php" method="post" enctype="multipart/form-data">

<table border="1" width="60%" align="center" >
	
	<tr>
	 <td width="30%"> Old Password </td>
	 <td width="10%" align="center"> : </td>
	 <td width="30%"><input required="required" type="password" name="oldpassword" id="oldpassword"></td>	
    </tr>

	<tr>
	 <td width="30%"> Password </td>
	 <td width="10%" align="center"> : </td>
	 <td width="30%"><input required="required" type="password" name="password" id="password"></td>	
    </tr>

    <tr>
	 <td width="30%"> Confirm Password </td>
	 <td width="10%" align="center"> : </td>
	 <td width="30%"><input required="required" type="password" name="cnpassword" id="cnpassword"></td>	
    </tr>

	<tr>
	 <td colspan="3" align="center"> <input type="submit" value="Update" name="submit"> </td>
	</tr>

</table>

</form>

</div>
</div>