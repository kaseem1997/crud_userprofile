<!DOCTYPE html>
<html>
<head><title>Register User</title>
</head>
<body>

<form action="create_user.php" method="post" enctype="multipart/form-data">

<table border="1" width="40%" align="center" >

	<tr>
	 <td width="30%"> Name </td>
	 <td width="10%" align="center"> : </td>
	 <td width="30%"><input class="text-style" required="required" type="text" name="name" id="name" placeholder="Write full name"> </td>	
    </tr>

    <tr>
	 <td> DOB </td>
	 <td width="10%" align="center"> : </td>
	 <td><input class="text-style" required="required" type="form-data" name="dob" id="dob" placeholder="YYYY-MM-DD"></td>	
    </tr>

    <tr>
	 <td> Gender </td>
	 <td width="10%" align="center"> : </td>
	 <td>
	 	<input required="required" type="radio" name="gender" id="gender" value="Male"> Male
	 	<input required="required" type="radio" name="gender" id="gender" value="Female"> Female
	 </td>	
    </tr>

    <tr>
	 <td> Complete Address </td>
	 <td width="10%" align="center"> : </td>
	 <td width="30%"><input class="text-style" required="required" type="text" name="address" id="address" placeholder="Write full address"> </td>
    </tr>

    <tr>
	 <td> Profile Picture </td>
	 <td width="10%" align="center"> : </td>
	 <td><input required="required" type="file" name="profile_pic" id="profile_pic"> </td>	
    </tr>

    <tr>
    	<td>Enter credit card number</td>
    	<td width="10%" align="center"> : </td>
    	<td><input required="required" type="number" name="credit_card" id="credit_card" placeholder="Enter no of credit card"></td>
    </tr>
  
    <tr>
	 <td> Email/User Id </td>
	 <td width="10%" align="center"> : </td>
	 <td><input class="text-style" required="required" type="text" name="email" id="email" placeholder="Write email id"></td>	
    </tr>

    <tr>
	 <td> Password </td>
	 <td width="10%" align="center"> : </td>
	 <td><input class="text-style" required="required" type="password" name="password" id="password" placeholder="password"></td>	
    </tr>

    <tr>
	 <td colspan="3" align="center"> <input type="submit" value="Submit" name="submit"> </td>
	</tr>

	  
</form>

</table>

<p align="center">Already  have account, please  login from <a href="index.php"> here </a> </p>

</body>
</html>