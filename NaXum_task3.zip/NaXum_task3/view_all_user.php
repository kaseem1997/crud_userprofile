<?php
//check of user id logged in otherwise sent on login page.
include 'session_check.php';

// to get database connection.
include 'db_connection.php';
$userId = $_SESSION['userData']['id'];

$sel_query = "SELECT * FROM users";
$runQuery = $conn->query($sel_query);
?>

Welcome to <b> <?php echo $_SESSION['userData']['name'];?></b>

<div class="div_width" id="textbox">
  <div class="alignleft">
  	<?php include_once'left_panel.php';?>
  </div>

  <div class="alignright">
  	
  	<?php if(isset($_SESSION['message'])){echo "<p align='center' > ".$_SESSION['message']."</p>";unset($_SESSION['message']);}?>

  	<p align="center">Registration Users List</p>
  	
	<table border="1" width="60%" align="center" >
		<tr>
		 <th> Name </th>
		 <th> Email/User Id </th>
		 <th> Credit Card </th>
		 <th> Gender </th>
		 <th> DOB </th>
		 <th> Address </th>
		 <th> Profile Picture </th>
		 <th>Action</th>
	</tr>

<?php while($data = $runQuery->fetch_assoc()) {?>		
	<tr>
		 <td><?= $data['name']?></td>
		 <td> <?= $data['email']?></td>
		 <td> <?= $data['credit_card']?> </td>
		 <td> <?= $data['gender']?> </td>
		 <td> <?= $data['dob']?> </td>
		 <td> <?= $data['address']?> </td>
		 <td> 
		 
		 <?php if(!empty($data['profile_pic'])) { ?> 		 		
		 	<img src="<?= $data['profile_pic']?>" width="50" />
		 <?php }else {echo "N/A";}?>
		 
		 </td>
		 
		 <td> <a href="delete.php?id=<?= $data['id']?>"> Delete </a> | <a href="update-user-profile.php?id=<?= $data['id']?>"> Edit </a></td>
	</tr>
<?php }?>

</table>

  </div>
</div>