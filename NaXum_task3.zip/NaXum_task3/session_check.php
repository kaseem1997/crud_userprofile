<?php
session_start();
if(empty($_SESSION["userData"]))
{
	$_SESSION["message"] = "Please login to view this page.";
	
	header("Location:index.php");
}
?>