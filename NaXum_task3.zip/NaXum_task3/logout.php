<?php session_start();
unset($_SESSION['userData']);
$_SESSION["message"] = "Successfully Logout.";
header("Location:index.php");
?>
